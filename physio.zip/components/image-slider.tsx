// "use client";

// import * as React from "react";
// import Image from "next/image";
// import { AnimatePresence, motion } from "framer-motion";

// interface ImageItem {
//   src: string;
//   alt: string;
//   width: number;
//   height: number;
// }

// const images: ImageItem[] = [
//   {
//     src: "/child/child-therapy-session-1.jpg",
//     alt: "image not found",
//     width: 600,
//     height: 300,
//   },
//   {
//     src: "/child/child-therapy-session-1.jpg",
//     alt: "image not found",
//     width: 600,
//     height: 300,
//   },
//   {
//     src: "/child/child-therapy-session-2.jpg",
//     alt: "image not found",
//     width: 600,
//     height: 300,
//   },
//   {
//     src: "/child/child-therapy-session-3.jpg",
//     alt: "image not found",
//     width: 600,
//     height: 300,
//   },
//   {
//     src: "/child/child-therapy-session-4.jpg",
//     alt: "image not found",
//     width: 600,
//     height: 300,
//   },
//   {
//     src: "/child/child-therapy-session-5.jpg",
//     alt: "image not found",
//     width: 600,
//     height: 300,
//   },
//   {
//     src: "/child/child-therapy-session-6.jpg",
//     alt: "image not found",
//     width: 600,
//     height: 300,
//   },
//   {
//     src: "/child/child-therapy-session-6(2).jpg",
//     alt: "image not found",
//     width: 600,
//     height: 300,
//   },
//   {
//     src: "/child/child-therapy-session-7.jpg",
//     alt: "image not found",
//     width: 600,
//     height: 300,
//   },
//   {
//     src: "/child/child-therapy-session-8.jpg",
//     alt: "image not found",
//     width: 600,
//     height: 300,
//   },
// ];

// interface ImageSliderProps {
//   maxWidthClass?: string;
//   heightClass?: string;
// }

// export default function ImageSlider({
//   maxWidthClass = "max-w-4xl",
//   heightClass = "h-[300px]",
// }: ImageSliderProps) {
//   const [currentIndex, setCurrentIndex] = React.useState(0);
//   const [direction, setDirection] = React.useState(0);

//   const handleNext = React.useCallback(() => {
//     setDirection(1);
//     setCurrentIndex((prev) => (prev + 1) % images.length);
//   }, []);

//   React.useEffect(() => {
//     const interval = setInterval(handleNext, 2000); // 5s auto-switch
//     return () => clearInterval(interval);
//   }, [handleNext]);

//   const variants = {
//     enter: (dir: number) => ({
//       x: dir > 0 ? "100%" : "-100%",
//       opacity: 0,
//     }),
//     center: {
//       x: 0,
//       opacity: 1,
//     },
//     exit: (dir: number) => ({
//       x: dir < 0 ? "100%" : "-100%",
//       opacity: 0,
//     }),
//   };

//   return (
//     <div
//       className={`relative w-full ${maxWidthClass} mx-auto overflow-hidden rounded-xl shadow-lg`}
//     >
//       <div className={`relative w-full ${heightClass}`}>
//         <AnimatePresence initial={false} custom={direction}>
//           <motion.div
//             key={currentIndex}
//             custom={direction}
//             variants={variants}
//             initial="enter"
//             animate="center"
//             exit="exit"
//             transition={{
//               x: { type: "spring", stiffness: 300, damping: 30 },
//               opacity: { duration: 0.2 },
//             }}
//             className="absolute inset-0"
//           >
//             <Image
//               src={images[currentIndex].src}
//               alt={images[currentIndex].alt}
//               width={images[currentIndex].width}
//               height={images[currentIndex].height}
//               className="w-full h-full object-cover"
//               priority={currentIndex === 0}
//             />
//           </motion.div>
//         </AnimatePresence>
//       </div>
//     </div>
//   );
// }
"use client";

import * as React from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface ImageItem {
  src: string;
  alt: string;
  id: string; // Better for React keys than index
}

const images: ImageItem[] = [
  {
    id: "therapy-1",
    src: "/child/child-therapy-session-1.jpg",
    alt: "Child therapy session - therapeutic activities",
  },
  {
    id: "therapy-1-duplicate", // Note: you have a duplicate image
    src: "/child/child-therapy-session-1.jpg",
    alt: "Child therapy session - therapeutic activities",
  },
  {
    id: "therapy-2",
    src: "/child/child-therapy-session-2.jpg",
    alt: "Child therapy session - exercise and movement",
  },
  {
    id: "therapy-3",
    src: "/child/child-therapy-session-3.jpg",
    alt: "Child therapy session - rehabilitation activities",
  },
  {
    id: "therapy-4",
    src: "/child/child-therapy-session-4.jpg",
    alt: "Child therapy session - physical development",
  },
  {
    id: "therapy-5",
    src: "/child/child-therapy-session-5.jpg",
    alt: "Child therapy session - motor skills training",
  },
  {
    id: "therapy-6",
    src: "/child/child-therapy-session-6.jpg",
    alt: "Child therapy session - play-based therapy",
  },
  {
    id: "therapy-6-alt",
    src: "/child/child-therapy-session-6(2).jpg",
    alt: "Child therapy session - play-based therapy alternative",
  },
  {
    id: "therapy-7",
    src: "/child/child-therapy-session-7.jpg",
    alt: "Child therapy session - strength building",
  },
  {
    id: "therapy-8",
    src: "/child/child-therapy-session-8.jpg",
    alt: "Child therapy session - coordination training",
  },
];

interface ImageSliderProps {
  maxWidthClass?: string;
  heightClass?: string;
  autoSlideInterval?: number;
  showNavigation?: boolean;
  showIndicators?: boolean;
}

export default function ImageSlider({
  maxWidthClass = "max-w-4xl",
  heightClass = "h-[400px] md:h-[500px] lg:h-[600px]", // Responsive heights
  autoSlideInterval = 4000, // Slower for better UX
  showNavigation = true,
  showIndicators = true,
}: ImageSliderProps) {
  const [currentIndex, setCurrentIndex] = React.useState(0);
  const [direction, setDirection] = React.useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = React.useState(true);
  const [imageErrors, setImageErrors] = React.useState<Set<string>>(new Set());

  // Navigation functions
  const goToNext = React.useCallback(() => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % images.length);
  }, []);

  const goToPrevious = React.useCallback(() => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
  }, []);

  const goToSlide = React.useCallback(
    (index: number) => {
      const newDirection = index > currentIndex ? 1 : -1;
      setDirection(newDirection);
      setCurrentIndex(index);
    },
    [currentIndex]
  );

  // Auto-slide effect
  React.useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(goToNext, autoSlideInterval);
    return () => clearInterval(interval);
  }, [goToNext, autoSlideInterval, isAutoPlaying]);

  // Pause auto-slide on hover
  const handleMouseEnter = () => setIsAutoPlaying(false);
  const handleMouseLeave = () => setIsAutoPlaying(true);

  // Handle image load errors
  const handleImageError = React.useCallback((imageSrc: string) => {
    setImageErrors((prev) => new Set([...prev, imageSrc]));
  }, []);

  // Preload next images for better performance
  React.useEffect(() => {
    const preloadImages = () => {
      const nextIndex = (currentIndex + 1) % images.length;
      const prevIndex = (currentIndex - 1 + images.length) % images.length;

      [nextIndex, prevIndex].forEach((index) => {
        const img = new window.Image();
        img.src = images[index].src;
      });
    };

    preloadImages();
  }, [currentIndex]);

  const variants = {
    enter: (dir: number) => ({
      x: dir > 0 ? "100%" : "-100%",
      opacity: 0,
      scale: 0.95,
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
    },
    exit: (dir: number) => ({
      x: dir < 0 ? "100%" : "-100%",
      opacity: 0,
      scale: 0.95,
    }),
  };

  // Filter out images that failed to load
  const validImages = images.filter((img) => !imageErrors.has(img.src));
  const currentImage = validImages[currentIndex] || images[0];

  if (validImages.length === 0) {
    return (
      <div
        className={`relative w-full ${maxWidthClass} mx-auto ${heightClass} rounded-xl bg-gray-200 flex items-center justify-center`}
      >
        <p className="text-gray-500">No images available</p>
      </div>
    );
  }

  return (
    <div
      className={`relative w-full ${maxWidthClass} mx-auto group`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Main slider container */}
      <div
        className={`relative w-full ${heightClass} overflow-hidden rounded-xl shadow-lg bg-gray-100`}
      >
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentImage.id}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.3 },
              scale: { duration: 0.3 },
            }}
            className="absolute inset-0"
          >
            <Image
              src={currentImage.src}
              alt={currentImage.alt}
              fill
              className="object-cover object-center" // Responsive object-fit
              sizes={`(max-width: 768px) 100vw, (max-width: 1200px) 80vw, 1200px`}
              priority={currentIndex === 0}
              quality={85} // Optimize quality vs file size
              onError={() => handleImageError(currentImage.src)}
              placeholder="blur"
              blurDataURL="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAAIAAoDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAv/xAAhEAACAQMDBQAAAAAAAAAAAAABAgMABAUGIWGRkqGx0f/EABUBAQEAAAAAAAAAAAAAAAAAAAMF/8QAGhEAAgIDAAAAAAAAAAAAAAAAAAECEgMRkf/aAAwDAQACEQMRAD8AltJagyeH0AthI5xdrLcNM91BF5pX2HaH9bcfaSXWGaRmknyJckliyjqTzSlT54b6bk+h0R//2Q=="
            />
          </motion.div>
        </AnimatePresence>

        {/* Loading overlay */}
        <div
          className="absolute inset-0 bg-gray-200 animate-pulse"
          style={{ zIndex: -1 }}
        />
      </div>

      {/* Navigation arrows */}
      {showNavigation && validImages.length > 1 && (
        <>
          <button
            onClick={goToPrevious}
            className="absolute left-2 top-1/2 -translate-y-1/2 z-10 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-all duration-200 opacity-0 group-hover:opacity-100"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={goToNext}
            className="absolute right-2 top-1/2 -translate-y-1/2 z-10 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-all duration-200 opacity-0 group-hover:opacity-100"
            aria-label="Next image"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </>
      )}

      {/* Indicators */}
      {showIndicators && validImages.length > 1 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 flex space-x-2">
          {validImages.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2 h-2 rounded-full transition-all duration-200 ${
                index === currentIndex
                  ? "bg-white scale-125"
                  : "bg-white/50 hover:bg-white/75"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}

      {/* Image counter */}
      <div className="absolute top-4 right-4 z-10 bg-black/50 text-white px-2 py-1 rounded text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        {currentIndex + 1} / {validImages.length}
      </div>
    </div>
  );
}
