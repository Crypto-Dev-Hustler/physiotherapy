// // // "use client"

// // // import { MapPinned, Award, Badge, BookmarkCheck, Bolt } from "lucide-react"
// // // import Image from "next/image"

// // // export function ChildDetailSection() {
// // //     return (
// // //         <section id="childdetails" className="lg:h-screen flex w-screen">
// // //             <div className="lg:w-1/2 flex items-center pl-0 lg:pl-10">
// // //                 <div className="gap-4 flex flex-col justify-center lg:pl-10 lg:pr-10 pl-5 pr-5">
// // //                     <h2 className="text-4xl lg:text-4xl pt-10 lg:pt-0 font-bold mb-8 text-gray-900">Child Center</h2>
// // //                     <div className="flex">
// // //                         <Award className="text-blue-600"/>
// // //                         <span className="text-gray-900 pl-6">1500+ satisfied patients</span>
// // //                     </div>
// // //                     <div className="flex">
// // //                         <Badge className="text-blue-600"/>
// // //                         <span className="pl-6">3+ years of working experience</span>
// // //                     </div>
// // //                     <div className="flex">
// // //                         <BookmarkCheck className="text-blue-600"/>
// // //                         <span className="pl-6">40+ therapies and techniques</span>
// // //                     </div>
// // //                     <div className="flex">
// // //                         <Bolt className="text-blue-600"/>
// // //                         <span className="text-gray-900 pl-6">Monday to Saturday (9:00 am to 8:00 pm)</span>
// // //                     </div>
// // //                     <div className="flex">
// // //                         <MapPinned className="text-blue-600"/>
// // //                         <span className="text-gray-900 pl-6">1655p basement (Near by Doordarshan Appartment), Sector-45, Gurugram</span>
// // //                     </div>
// // //                     <button className="w-40 h-10 mb-10 lg:mb-0 rounded-lg text-white bg-blue-600 mt-2">
// // //                         Book Appointment
// // //                     </button>
// // //                 </div>
// // //             </div>
// // //             <div className="lg:w-1/2 w-0 h-0 lg:h-screen flex items-center invisible lg:visible">
// // //                             <div className="flex justify-center items-center h-full lg:h-1/2">
// // //                                 <Image src={"/d01.jpg"} alt="hi" width={"700"} height={10} className="rounded-lg w-full h-full object-cover" />
// // //                             </div>
// // //                         </div>
// // //         </section>
// // //     )
// // // }

// // "use client";

// // import { MapPinned, Award, Badge, BookmarkCheck, Bolt } from "lucide-react";
// // import Image from "next/image";

// // export function ChildDetailSection() {
// //   return (
// //     <section id="childdetails" className="lg:h-dvh flex w-screen">
// //       {/* Content Section */}
// //       <div className="lg:w-1/2 flex items-center pl-0 lg:pl-10">
// //         <div className="gap-4 flex flex-col justify-center lg:pl-10 lg:pr-10 pl-5 pr-5">
// //           <h2 className="text-4xl lg:text-4xl pt-10 lg:pt-0 font-bold mb-8 text-gray-900">
// //             Child Center
// //           </h2>

// //           <div className="flex">
// //             <Award className="text-blue-600" />
// //             <span className="text-gray-900 pl-6">1500+ satisfied patients</span>
// //           </div>

// //           <div className="flex">
// //             <Badge className="text-blue-600" />
// //             <span className="pl-6">3+ years of working experience</span>
// //           </div>

// //           <div className="flex">
// //             <BookmarkCheck className="text-blue-600" />
// //             <span className="pl-6">40+ therapies and techniques</span>
// //           </div>

// //           <div className="flex">
// //             <Bolt className="text-blue-600" />
// //             <span className="text-gray-900 pl-6">
// //               Monday to Saturday (9:00 am to 8:00 pm)
// //             </span>
// //           </div>

// //           <div className="flex">
// //             <MapPinned className="text-blue-600" />
// //             <span className="text-gray-900 pl-6">
// //               Pediatrics - God gift child development center house number 1655
// //               basement sector 45 nearby doordarshan apartment
// //             </span>
// //           </div>

// //           <button className="w-40 h-10 mb-10 lg:mb-0 rounded-lg text-white bg-blue-600 mt-2 hover:bg-blue-700 transition">
// //             Book Appointment
// //           </button>
// //         </div>
// //       </div>

// //       {/* Image Section */}
// //       <div className="lg:w-1/2 w-0 h-0 lg:h-dvh flex items-center invisible lg:visible">
// //         <div className="flex justify-center items-center h-full lg:h-1/2">
// //           <Image
// //             src="/d01.jpg"
// //             alt="Child Center"
// //             width={700}
// //             height={500}
// //             className="rounded-lg w-full h-full object-cover"
// //           />
// //         </div>
// //       </div>
// //     </section>
// //   );
// // }

// "use client";

// import {
//   MapPinned,
//   Award,
//   Badge,
//   BookmarkCheck,
//   Bolt,
//   Users,
//   Heart,
//   Shield,
//   Clock,
//   Star,
//   Phone,
//   Mail,
//   Calendar,
// } from "lucide-react";
// import Image from "next/image";

// export function ChildDetailSection() {
//   return (
//     <section
//       id="childdetails"
//       className="lg:h-dvh flex w-screen bg-gradient-to-br from-blue-50 to-white"
//     >
//       {/* Content Section */}
//       <div className="lg:w-1/2 flex items-center pl-0 lg:pl-10">
//         <div className="gap-6 flex flex-col justify-center lg:pl-10 lg:pr-10 pl-5 pr-5 py-10">
//           <div>
//             <h2 className="text-4xl lg:text-5xl pt-10 lg:pt-0 font-bold mb-4 text-gray-900">
//               Child Development Center
//             </h2>
//             <p className="text-lg text-gray-600 mb-8 leading-relaxed">
//               Specialized care for children with developmental needs, autism,
//               ADHD, cerebral palsy, and speech delays. Our expert team provides
//               personalized therapy programs in a nurturing environment.
//             </p>
//           </div>

//           {/* Key Stats */}
//           <div className="grid grid-cols-1 gap-4 mb-6">
//             <div className="flex items-center bg-white p-3 rounded-lg shadow-sm">
//               <Award className="text-blue-600 mr-4" size={24} />
//               <span className="text-gray-900 font-medium">
//                 1500+ satisfied patients & families
//               </span>
//             </div>

//             <div className="flex items-center bg-white p-3 rounded-lg shadow-sm">
//               <Badge className="text-blue-600 mr-4" size={24} />
//               <span className="text-gray-900 font-medium">
//                 3+ years specialized pediatric experience
//               </span>
//             </div>

//             <div className="flex items-center bg-white p-3 rounded-lg shadow-sm">
//               <BookmarkCheck className="text-blue-600 mr-4" size={24} />
//               <span className="text-gray-900 font-medium">
//                 40+ evidence-based therapies & techniques
//               </span>
//             </div>

//             <div className="flex items-center bg-white p-3 rounded-lg shadow-sm">
//               <Users className="text-blue-600 mr-4" size={24} />
//               <span className="text-gray-900 font-medium">
//                 Ages 0-18 years • Individual & group sessions
//               </span>
//             </div>
//           </div>

//           {/* Services Offered */}
//           <div className="bg-white p-4 rounded-lg shadow-sm mb-4">
//             <h3 className="font-bold text-gray-900 mb-3 flex items-center">
//               <Heart className="text-red-500 mr-2" size={20} />
//               Specialized Services
//             </h3>
//             <div className="text-sm text-gray-600 grid grid-cols-2 gap-2">
//               <span>• Speech Therapy</span>
//               <span>• Occupational Therapy</span>
//               <span>• Behavioral Therapy</span>
//               <span>• Autism Support</span>
//               <span>• ADHD Management</span>
//               <span>• Sensory Integration</span>
//             </div>
//           </div>

//           {/* Contact & Hours */}
//           <div className="space-y-3">
//             <div className="flex items-center">
//               <Bolt className="text-green-600 mr-4" size={20} />
//               <span className="text-gray-900 font-medium">
//                 Monday to Saturday (9:00 AM - 7:00 PM)
//               </span>
//             </div>

//             <div className="flex items-start">
//               <MapPinned className="text-blue-600 mr-4 mt-1" size={20} />
//               <a
//                 href="https://maps.app.goo.gl/BhftUaJ6eUeTrdeGA"
//                 target="_blank"
//                 className="text-blue-400 underline"
//                 rel="noopener noreferrer"
//               >
//                 <span className="text-gray-900 text-sm leading-relaxed">
//                   House No. 1655, Basement, Sector-45
//                   <br />
//                   Near Doordarshan Apartment, Gurugram
//                 </span>
//               </a>
//             </div>

//             <div className="flex items-center">
//               <Phone className="h-5 w-5 mr-3 flex-shrink-0" />
//               <a href="tel:+917078571204" className="text-blue-400 underline">
//                 <span>+91 7078571204</span>
//               </a>
//             </div>

//             <div className="flex items-center">
//               <Mail className="text-blue-600 mr-4" size={20} />
//               <a
//                 href="mailto:painfreephysiodrpriyanka@gmail.com"
//                 className="text-blue-400 underline"
//               >
//                 <span>painfreephysiodrpriyanka@gmail.com</span>
//               </a>
//             </div>
//           </div>

//           {/* Safety & Quality
//           <div className="bg-green-50 p-4 rounded-lg border border-green-200">
//             <div className="flex items-center mb-2">
//               <Shield className="text-green-600 mr-2" size={20} />
//               <span className="font-bold text-green-800">
//                 Safe & Certified Environment
//               </span>
//             </div>
//             <p className="text-sm text-green-700">
//               Child-safe facilities • Licensed therapists • Regular progress
//               monitoring • Parent training included
//             </p>
//           </div> */}

//           {/* Action Buttons */}
//           <div className="flex flex-col sm:flex-row gap-3 mt-4">
//             <a
//               href="#booking"
//               className="flex-1 h-12 rounded-lg text-white bg-blue-600 hover:bg-blue-700 transition font-medium flex items-center justify-center"
//               onClick={(e) => {
//                 e.preventDefault();
//                 const bookingSection = document.getElementById("booking");
//                 if (bookingSection) {
//                   bookingSection.scrollIntoView({
//                     behavior: "smooth",
//                     block: "start",
//                   });
//                   history.replaceState(null, "", "#booking");
//                 }
//               }}
//             >
//               <Calendar className="mr-2" size={18} />
//               Book Appointment
//             </a>
//           </div>

//           {/* Quick Stats */}
//         </div>
//       </div>

//       {/* Image Section */}
//       <div className="lg:w-1/2 w-0 h-0 lg:h-dvh flex items-center invisible lg:visible">
//         <div className="flex justify-center items-center h-full lg:h-4/5 p-8">
//           <div className="relative w-full h-full">
//             <Image
//               src="/d01.jpg"
//               alt="Child Development Center - Therapist working with child"
//               width={700}
//               height={500}
//               className="rounded-2xl w-full h-full object-cover shadow-xl"
//               priority
//             />
//             {/* Overlay Badge */}
//             <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
//               <div className="flex items-center">
//                 <Star className="text-yellow-500 mr-1" size={16} />
//                 <span className="text-sm font-bold text-gray-900">
//                   4.9/5 Rating
//                 </span>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </section>
//   );
// }

"use client";

import {
  MapPinned,
  Award,
  Badge,
  BookmarkCheck,
  Bolt,
  Users,
  Heart,
  Shield,
  Clock,
  Star,
  Phone,
  Mail,
  Calendar,
} from "lucide-react";
import Image from "next/image";
import ImageSlider from "../image-slider";

export function ChildDetailSection() {
  return (
    <section
      id="childdetails"
      className="min-h-screen flex flex-col lg:flex-row w-full bg-gradient-to-br from-blue-50 to-white"
    >
      {/* Content Section */}
      <div className="w-full lg:w-1/2 flex items-center order-2 lg:order-1">
        <div className="w-full max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 py-8 lg:py-12">
          {/* Header */}
          <div className="mb-6 lg:mb-8">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold mb-4 text-gray-900 leading-tight">
              Child Development Center
            </h2>
            <p className="text-base sm:text-lg lg:text-xl text-gray-600 leading-relaxed">
              Specialized care for children with developmental needs, autism,
              ADHD, cerebral palsy, and speech delays. Our expert team provides
              personalized therapy programs in a nurturing environment.
            </p>
          </div>

          {/* Key Stats - Mobile Optimized */}
          <div className="space-y-3 sm:space-y-4 mb-6 lg:mb-8">
            <div className="flex items-start sm:items-center bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <Award
                className="text-blue-600 mr-3 sm:mr-4 mt-1 sm:mt-0 flex-shrink-0"
                size={20}
              />
              <span className="text-gray-900 font-medium text-sm sm:text-base">
                1500+ satisfied patients & families
              </span>
            </div>

            <div className="flex items-start sm:items-center bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <Badge
                className="text-blue-600 mr-3 sm:mr-4 mt-1 sm:mt-0 flex-shrink-0"
                size={20}
              />
              <span className="text-gray-900 font-medium text-sm sm:text-base">
                3+ years specialized pediatric experience
              </span>
            </div>

            <div className="flex items-start sm:items-center bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <BookmarkCheck
                className="text-blue-600 mr-3 sm:mr-4 mt-1 sm:mt-0 flex-shrink-0"
                size={20}
              />
              <span className="text-gray-900 font-medium text-sm sm:text-base">
                40+ evidence-based therapies & techniques
              </span>
            </div>

            <div className="flex items-start sm:items-center bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <Users
                className="text-blue-600 mr-3 sm:mr-4 mt-1 sm:mt-0 flex-shrink-0"
                size={20}
              />
              <span className="text-gray-900 font-medium text-sm sm:text-base">
                Ages 0-18 years • Individual & group sessions
              </span>
            </div>
          </div>

          {/* Services Offered - Mobile Optimized Grid */}
          <div className="bg-white p-4 sm:p-5 rounded-lg shadow-sm mb-6">
            <h3 className="font-bold text-gray-900 mb-4 flex items-center text-base sm:text-lg">
              <Heart className="text-red-500 mr-2 flex-shrink-0" size={20} />
              Specialized Services
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 text-sm sm:text-base text-gray-600">
              <span>• Speech Therapy</span>
              <span>• Occupational Therapy</span>
              <span>• Behavioral Therapy</span>
              <span>• Autism Support</span>
              <span>• ADHD Management</span>
              <span>• Sensory Integration</span>
            </div>
          </div>

          {/* Contact & Hours - Mobile Optimized */}
          <div className="space-y-4 mb-6 lg:mb-8">
            <div className="flex items-start">
              <Bolt
                className="text-green-600 mr-3 mt-1 flex-shrink-0"
                size={18}
              />
              <div className="flex-1">
                <span className="text-gray-900 font-medium text-sm sm:text-base block">
                  Monday to Saturday
                </span>
                <span className="text-gray-600 text-sm">9:00 AM - 7:00 PM</span>
              </div>
            </div>

            <div className="flex items-start">
              <MapPinned
                className="text-blue-600 mr-3 mt-1 flex-shrink-0"
                size={18}
              />
              <div className="flex-1">
                <a
                  href="https://maps.app.goo.gl/BhftUaJ6eUeTrdeGA"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800 transition-colors"
                >
                  <span className="text-gray-900 text-sm sm:text-base leading-relaxed block hover:underline">
                    House No. 1655, Basement, Sector-45
                    <br />
                    Near Doordarshan Apartment, Gurugram
                  </span>
                </a>
              </div>
            </div>

            <div className="flex items-center">
              <Phone className="text-green-600 mr-3 flex-shrink-0" size={18} />
              <a
                href="tel:+917078571204"
                className="text-blue-600 hover:text-blue-800 transition-colors text-sm sm:text-base font-medium hover:underline"
              >
                +91 7078571204
              </a>
            </div>

            <div className="flex items-start">
              <Mail
                className="text-blue-600 mr-3 mt-1 flex-shrink-0"
                size={18}
              />
              <a
                href="mailto:painfreephysiodrpriyanka@gmail.com"
                className="text-blue-600 hover:text-blue-800 transition-colors text-sm sm:text-base hover:underline break-all"
              >
                painfreephysiodrpriyanka@gmail.com
              </a>
            </div>
          </div>

          {/* Action Button - Full Width on Mobile */}
          <div className="mb-6 lg:mb-0">
            <a
              href="#booking"
              className="w-full h-12 sm:h-14 rounded-lg text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 transition-all font-medium flex items-center justify-center text-base sm:text-lg shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95"
              onClick={(e) => {
                e.preventDefault();
                const bookingSection = document.getElementById("booking");
                if (bookingSection) {
                  bookingSection.scrollIntoView({
                    behavior: "smooth",
                    block: "start",
                  });
                  history.replaceState(null, "", "#booking");
                }
              }}
            >
              <Calendar className="mr-2 flex-shrink-0" size={20} />
              Book Appointment
            </a>
          </div>
        </div>
      </div>

      {/* Image Section - Mobile Optimized */}
      <div className="w-full lg:w-1/2 h-64 sm:h-80 md:h-96 lg:h-auto order-1 lg:order-2">
        <div className="relative w-full h-full lg:h-screen flex items-center justify-center p-4 lg:p-8">
          <div className="relative w-full h-full max-w-lg lg:max-w-none">
            {/* <Image
              src="/d01.jpg"
              alt="Child Development Center - Therapist working with child"
              fill
              className="rounded-xl lg:rounded-2xl object-cover shadow-lg lg:shadow-xl"
              priority
              sizes="(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 50vw"
            /> */}

            <ImageSlider maxWidthClass="max-w-xl" heightClass="h-[275px]" />

            {/* Overlay Badge - Responsive */}
            <div className="absolute top-2 sm:top-4 left-2 sm:left-4 bg-white/90 backdrop-blur-sm px-2 sm:px-4 py-1 sm:py-2 rounded-full shadow-lg">
              <div className="flex items-center">
                <Star
                  className="text-yellow-500 mr-1 flex-shrink-0"
                  size={14}
                />
                <span className="text-xs sm:text-sm font-bold text-gray-900 whitespace-nowrap">
                  4.9/5 Rating
                </span>
              </div>
            </div>

            {/* Mobile CTA Overlay
            <div className="absolute bottom-4 left-4 right-4 lg:hidden">
              <div className="bg-white/95 backdrop-blur-sm p-3 rounded-lg shadow-lg border">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-900 mb-2">
                    Ready to get started?
                  </p>
                  <div className="flex items-center justify-center text-xs text-gray-600">
                    <Phone size={12} className="mr-1" />
                    <span>Call now: +91 7078571204</span>
                  </div>
                </div>
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </section>
  );
}
