(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_3435ab51._.js",
  "static/chunks/node_modules_d6362d9c._.js"
],
    source: "dynamic"
});
