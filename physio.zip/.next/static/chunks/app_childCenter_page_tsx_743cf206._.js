(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_7bf3eb9d._.js",
  "static/chunks/node_modules_53fc2233._.js",
  "static/chunks/components_styles_mobile-calendar_1019baba.css"
],
    source: "dynamic"
});
