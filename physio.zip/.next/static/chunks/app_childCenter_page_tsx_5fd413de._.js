(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_7b7ee9ec._.js",
  "static/chunks/node_modules_473e6d97._.js",
  "static/chunks/components_styles_mobile-calendar_1019baba.css"
],
    source: "dynamic"
});
