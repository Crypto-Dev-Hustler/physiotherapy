(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_appoinment_tsx_760cf19f._.js",
  "static/chunks/_8e1dd4fb._.js",
  "static/chunks/node_modules_motion-dom_dist_es_4eeaac89._.js",
  "static/chunks/node_modules_framer-motion_dist_es_d4841561._.js",
  "static/chunks/node_modules_next_9f839c9b._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_0ee65af4._.js"
],
    source: "dynamic"
});
