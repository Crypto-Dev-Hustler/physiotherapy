(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_appoinment_tsx_b8353730._.js",
  "static/chunks/_8e1dd4fb._.js",
  "static/chunks/node_modules_7fb542d5._.js"
],
    source: "dynamic"
});
