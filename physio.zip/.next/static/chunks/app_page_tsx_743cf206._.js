(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_appoinment_tsx_6ed141e8._.js",
  "static/chunks/_68d0fe2a._.js",
  "static/chunks/node_modules_c5ce39ae._.js"
],
    source: "dynamic"
});
