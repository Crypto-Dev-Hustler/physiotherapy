(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_appoinment_tsx_d3f08b84._.js",
  "static/chunks/_68d0fe2a._.js",
  "static/chunks/node_modules_fc720f0c._.js"
],
    source: "dynamic"
});
