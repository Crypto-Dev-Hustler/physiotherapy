(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/components/navigation-menu.tsx [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, k: __turbopack_refresh__, m: module, e: exports } = __turbopack_context__;
{
// "use client";
// import { X, ArrowRight, Instagram, Mail, Phone, Facebook } from "lucide-react";
// import { Button } from "@/components/ui/button";
// import Image from "next/image";
// import { usePathname } from "next/navigation";
// import Link from "next/link";
// import type { MouseEvent } from "react";
// type NavigationMenuProps = {
//   isOpen: boolean;
//   onClose: () => void;
// };
// type NavItem = {
//   label: string;
//   href: `#${string}` | string; // Allow both hash links and regular URLs
//   isExternal?: boolean; // Flag to identify external/page links
// };
// export default function NavigationMenu({
//   isOpen,
//   onClose,
// }: NavigationMenuProps) {
//   const pathname = usePathname();
//   const isChildPage = pathname.startsWith("/childCenter");
//   // Adult page navigation items
//   const adultNavigationItems: NavItem[] = [
//     { label: "Home.", href: "#home" },
//     { label: "Adults.", href: "#adult" },
//     { label: "Children.", href: "#child" },
//     { label: "About.", href: "#adultdoctors" },
//   ];
//   // Child page navigation items
//   const childNavigationItems: NavItem[] = [
//     { label: "Home.", href: "#childhome" },
//     { label: "Details.", href: "#childdetails" },
//     { label: "Services.", href: "#childservices" },
//     { label: "Doctors.", href: "#childdoctors" },
//     { label: "Adult.", href: "/", isExternal: true }, // Navigate to home page
//     { label: "Booking.", href: "#booking" },
//   ];
//   const adultNavigationItems: NavItem[] = [
//     { label: "Home.", href: "#adulthome" },
//     { label: "Details.", href: "#adultdetails" },
//     { label: "Services.", href: "#adultservices" },
//     { label: "Doctors.", href: "#adultdoctors" },
//     { label: "chlid", href: "/childCenter", isExternal: true }, // Navigate to home page
//     // { label: "", href: "/", isExternal: true }, // Navigate to home page
//     { label: "Booking.", href: "#booking" },
//   ];
//   // Choose navigation items based on current page
//   const navigationItems = isChildPage
//     ? childNavigationItems
//     : adultNavigationItems;
//   const socialIcons = [
//     {
//       icon: Instagram,
//       href: "https://www.instagram.com/god_gift_child45?utm_source=qr&igsh=cHNxOWVwMWNrYmI=",
//     },
//     { icon: Facebook, href: "#" },
//     { icon: Mail, href: "mailto:painfreephysiodrpriyanka@gmail.com" },
//     { icon: Phone, href: "tel:+917078571204" },
//   ];
//   // Smooth-scroll to in-page anchors and close overlay
//   const handleAnchorClick = (
//     e: MouseEvent<HTMLAnchorElement>,
//     href: string
//   ) => {
//     if (!href.startsWith("#")) return;
//     e.preventDefault();
//     const id = href.replace(/^#/, "");
//     const el = document.getElementById(id);
//     // Close menu first
//     onClose();
//     if (el) {
//       // Smooth scroll after the next frame
//       requestAnimationFrame(() => {
//         el.scrollIntoView({ behavior: "smooth", block: "start" });
//       });
//       // Update the URL hash without causing a jump
//       history.replaceState(null, "", `#${id}`);
//     }
//   };
//   // Handle external/page navigation
//   const handleExternalClick = () => {
//     onClose(); // Close the menu when navigating to external page
//   };
//   // Optional: smooth scrolling via CSS if you haven't set it globally
//   if (typeof document !== "undefined") {
//     const html = document.documentElement;
//     if (!html.style.scrollBehavior) {
//       html.style.scrollBehavior = "smooth";
//     }
//   }
//   return (
//     // Full-screen overlay to capture clicks outside the menu content
//     <div
//       className={`fixed inset-0 z-[100] transition-opacity duration-500
//       ${isOpen ? "opacity-100" : "opacity-0 pointer-events-none"}`}
//       role="dialog"
//       aria-modal={isOpen ? true : undefined}
//       aria-hidden={!isOpen}
//       onClick={onClose}
//     >
//       {/* Actual menu content, positioned and styled */}
//       <div
//         className={`absolute top-0 right-0 left-25 bottom-30 bg-white/70 rounded-3xl shadow-xl backdrop-blur-sm
//         transition-all duration-500 ease-in-out transform
//         ${isOpen ? "translate-x-0 scale-100" : "translate-x-full scale-95"}`}
//         onClick={(e) => e.stopPropagation()}
//       >
//         {/* Header with close + logo */}
//         <div className="flex justify-between items-end p-6">
//           <button
//             onClick={onClose}
//             className={`relative z-20 text-[#81b342] hover:text-gray-700 transition-all duration-500 delay-100
//             ${
//               isOpen
//                 ? "opacity-100 translate-y-0 rotate-0"
//                 : "opacity-0 -translate-y-4 rotate-180"
//             }`}
//             aria-label="Close navigation menu"
//           >
//             <X size={32} />
//           </button>
//           <Image
//             src="/logo.png"
//             alt="Company logo"
//             width={48}
//             height={48}
//             priority
//           />
//         </div>
//         {/* Main navigation */}
//         <div className="flex flex-col justify-center items-start px-12 h-full -mt-20">
//           <nav className="space-y-4">
//             {navigationItems.map((item, index) => {
//               const linkContent = (
//                 <span
//                   className={`block text-4xl md:text-5xl lg:text-6xl font-bold text-[#81b342] hover:text-gray-900
//                   transition-all duration-700 leading-tight
//                   ${
//                     isOpen
//                       ? "opacity-100 translate-x-0"
//                       : "opacity-0 -translate-x-12"
//                   }`}
//                   style={{
//                     transitionDelay: isOpen ? `${100 + index * 100}ms` : "0ms",
//                   }}
//                 >
//                   {item.label}
//                 </span>
//               );
//               // If it's an external link (like going to home page), use Next.js Link
//               if (item.isExternal) {
//                 return (
//                   <Link
//                     key={item.href}
//                     href={item.href}
//                     onClick={handleExternalClick}
//                     aria-label={`Go to ${item.label.replace(".", "")} section`}
//                   >
//                     {linkContent}
//                   </Link>
//                 );
//               }
//               // Otherwise, use regular anchor tag with smooth scrolling
//               return (
//                 <a
//                   key={item.href}
//                   href={item.href}
//                   onClick={(e) => handleAnchorClick(e, item.href)}
//                   aria-label={`Go to ${item.label.replace(".", "")} section`}
//                 >
//                   {linkContent}
//                 </a>
//               );
//             })}
//           </nav>
//         </div>
//         {/* Socials */}
//         <div className="fixed left-6 bottom-8 space-y-6">
//           {socialIcons.map((social, index) => {
//             const Icon = social.icon;
//             return (
//               <a
//                 key={`${social.href}-${index}`}
//                 href={social.href}
//                 target={social.href.startsWith("http") ? "_blank" : undefined}
//                 rel={
//                   social.href.startsWith("http")
//                     ? "noopener noreferrer"
//                     : undefined
//                 }
//                 className={`block text-[#81b342] hover:text-gray-900 transition-all duration-700
//                 ${
//                   isOpen
//                     ? "opacity-100 translate-y-0"
//                     : "opacity-0 translate-y-8"
//                 }`}
//                 style={{
//                   transitionDelay: isOpen ? `${600 + index * 100}ms` : "0ms",
//                 }}
//                 onClick={onClose}
//                 aria-label="Open social link"
//               >
//                 <Icon size={24} />
//               </a>
//             );
//           })}
//         </div>
//         {/* CTA */}
//         <div className="fixed bottom-8 right-8">
//           <a
//             href="#booking"
//             onClick={onClose}
//             aria-label="Go to appointment section"
//           >
//             <Button
//               className={`bg-white/50 hover:bg-white/70 text-[#81b342] border border-[#81b342]/50 backdrop-blur-sm
//               px-8 py-3 rounded-full text-lg font-medium transition-all duration-700 hover:scale-105
//               ${
//                 isOpen
//                   ? "opacity-100 translate-y-0 scale-100"
//                   : "opacity-0 translate-y-8 scale-95"
//               }`}
//               style={{ transitionDelay: isOpen ? "800ms" : "0ms" }}
//             >
//               Schedule a Visit
//               <ArrowRight className="ml-2" size={20} />
//             </Button>
//           </a>
//         </div>
//       </div>
//     </div>
//   );
// }
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/navbar.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Navbar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/navigation-menu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)"); // Import motion
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function Navbar() {
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Prevent body scroll while overlay is open
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar.useEffect": ()=>{
            document.body.style.overflow = isOpen ? "hidden" : "";
            return ({
                "Navbar.useEffect": ()=>{
                    document.body.style.overflow = "";
                }
            })["Navbar.useEffect"];
        }
    }["Navbar.useEffect"], [
        isOpen
    ]);
    const navbarAppearDelay = 2; // Adjust this value as needed
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].header, {
                initial: {
                    opacity: 0,
                    y: -100
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 0.2,
                    delay: navbarAppearDelay
                },
                className: "fixed inset-x-0 top-0 z-50 bg-white/5 backdrop-blur-sm rounded-3xl overflow-hidden mx-4 mt-4" // Added mt-4
                ,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-4 py-3 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: "/logo.png",
                                alt: "PhysioHealth rehabilitation center",
                                width: 300,
                                height: 300,
                                style: {
                                    width: "20%",
                                    height: "auto"
                                },
                                priority: true
                            }, void 0, false, {
                                fileName: "[project]/components/navbar.tsx",
                                lineNumber: 32,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/navbar.tsx",
                            lineNumber: 31,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setIsOpen(true),
                            className: `flex flex-col justify-center items-center w-12 h-12 rounded-lg transition-all duration-300
            ${isOpen ? "opacity-0 pointer-events-none" : "opacity-100"}`,
                            "aria-label": "Open navigation menu",
                            "aria-expanded": isOpen,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "w-6 h-0.5 bg-[#000000] mb-1.5 transition-all duration-300"
                                }, void 0, false, {
                                    fileName: "[project]/components/navbar.tsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "w-6 h-0.5 bg-[#000000] mb-1.5 transition-all duration-300"
                                }, void 0, false, {
                                    fileName: "[project]/components/navbar.tsx",
                                    lineNumber: 50,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "w-6 h-0.5 bg-[#000000] mb-1.5 transition-all duration-300"
                                }, void 0, false, {
                                    fileName: "[project]/components/navbar.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/navbar.tsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/navbar.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/navbar.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isOpen,
                onClose: ()=>setIsOpen(false)
            }, void 0, false, {
                fileName: "[project]/components/navbar.tsx",
                lineNumber: 56,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(Navbar, "vl0Rt3/A8evyRPW1OQ1AhRk4UhU=");
_c = Navbar;
var _c;
__turbopack_context__.k.register(_c, "Navbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/components/client-wrapper.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ClientWrapper)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$navbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/navbar.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ClientWrapper({ children }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const isAdminPage = pathname.startsWith("/adminBoard");
    const isChildPage = pathname.startsWith("/childCenter");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ClientWrapper.useEffect": ()=>{
            if ("scrollRestoration" in history) {
                history.scrollRestoration = "manual";
            }
        }
    }["ClientWrapper.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ClientWrapper.useEffect": ()=>{
            const setVh = {
                "ClientWrapper.useEffect.setVh": ()=>{
                    document.documentElement.style.setProperty("--vh", `${window.innerHeight * 0.01}px`);
                }
            }["ClientWrapper.useEffect.setVh"];
            setVh();
            window.addEventListener("resize", setVh);
            return ({
                "ClientWrapper.useEffect": ()=>window.removeEventListener("resize", setVh)
            })["ClientWrapper.useEffect"];
        }
    }["ClientWrapper.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            !isAdminPage && !isChildPage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$navbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/client-wrapper.tsx",
                lineNumber: 36,
                columnNumber: 41
            }, this),
            children
        ]
    }, void 0, true);
}
_s(ClientWrapper, "tjXKfJWuFDa0epp0CJaCeazyqhM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = ClientWrapper;
var _c;
__turbopack_context__.k.register(_c, "ClientWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=components_0b0d2e1a._.js.map