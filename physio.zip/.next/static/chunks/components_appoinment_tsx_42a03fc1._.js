(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/components/appoinment.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_addb633c._.js",
  {
    "path": "static/chunks/components_styles_mobile-calendar_1019baba.css",
    "included": [
      "[project]/components/styles/mobile-calendar.css [app-client] (css)"
    ]
  },
  "static/chunks/components_appoinment_tsx_51fc51e9._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/appoinment.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);