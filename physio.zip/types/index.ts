export type FormData = {
    _id: string;
    name: string;
    age: number;
    date: string;
    time: string;
    phone: string;
  };